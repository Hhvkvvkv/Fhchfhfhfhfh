import os
import sys

# ================== التثبيت والإعدادات ==================
os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"

print("جاري التحقق من المكتبات وتثبيتها...")
os.system("pip install -q pyTelegramBotAPI google-api-python-client google-auth-httplib2 google-auth-oauthlib requests pyrogram tgcrypto")
os.system("apt-get update -y > /dev/null 2>&1 && apt-get install -y ffmpeg > /dev/null 2>&1")

import telebot
from telebot import types
import json
from urllib.parse import urlparse, parse_qs
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import Flow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
import subprocess
import requests
import asyncio
import threading
import time

# ================== إعدادات البوت ==================
BOT_TOKEN = "8523824116:AAFmptpilnTWRWorc9rR4KKZrsImIDSUD74"
bot = telebot.TeleBot(BOT_TOKEN)

CLIENT_CONFIG = {
    "installed": {
        "client_id": "520374144855-3vu4kpkagsp02u528kvqavpfs3jp3jkt.apps.googleusercontent.com",
        "project_id": "midyear-choir-507408-j2",
        "auth_uri": "https://accounts.google.com/o/oauth2/auth",
        "token_uri": "https://oauth2.googleapis.com/token",
        "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
        "client_secret": "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",
        "redirect_uris": ["http://localhost"]
    }
}

SCOPES = [
    'https://www.googleapis.com/auth/youtube',
    'https://www.googleapis.com/auth/youtube.upload',
    'https://www.googleapis.com/auth/youtube.readonly'
]

user_data = {}
oauth_flows = {}

# ================== دوال المساعدة ==================
ACCOUNT_API_ID = 38635106
ACCOUNT_API_HASH = "e159cf0eb690131778801b19bfa8fb08"
_pyro_app = None
_pyro_loop = None
_pyro_thread = None
_pyro_lock = threading.Lock()


def _pyro_loop_thread():
    """Event loop واحد مخصص يعمل دائماً في خيط خلفي — يُستخدم لكل عمليات Pyrogram."""
    global _pyro_loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    _pyro_loop = loop
    loop.run_forever()


def _ensure_pyro_loop():
    global _pyro_thread
    if _pyro_loop is None:
        with _pyro_lock:
            if _pyro_loop is None and _pyro_thread is None:
                _pyro_thread = threading.Thread(target=_pyro_loop_thread, daemon=True)
                _pyro_thread.start()
                while _pyro_loop is None:
                    time.sleep(0.05)
    return _pyro_loop


async def _pyro_connect(_loop):
    from pyrogram import Client
    from pyrogram.errors import FloodWait

    client = Client(
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "pyro_bot"),
        api_id=ACCOUNT_API_ID,
        api_hash=ACCOUNT_API_HASH,
        bot_token=BOT_TOKEN,
        no_updates=True,
        workdir=os.path.dirname(os.path.abspath(__file__)),
    )
    attempts = 0
    while attempts < 5:
        try:
            await client.start()
            return client
        except FloodWait as e:
            seconds = int(getattr(e, "value", 30))
            print(f"[MTProto] FloodWait {seconds}ث — ننتظر...")
            await asyncio.sleep(min(seconds, 60))
            attempts += 1
    raise Exception("فشل بدء عميل MTProto بعد FloodWait متكرر.")


def get_pyro_client():
    """
    عميل Pyrogram (MTProto) مربوط بنفس بوت التيليجرام عبر bot_token.
    MTProto يسمح بتحميل ملفات حتى 2GB، بينما telebot (Bot API) يقتصر على 20MB.
    يعمل في خيط منفصل حتى لا يتعارض مع long-polling الخاص بـ telebot.infinity_polling().
    تُستدعى فقط من خيط خارجي (handlers) وليس من داخل coroutine.
    """
    global _pyro_app
    loop = _ensure_pyro_loop()
    if _pyro_app is None:
        with _pyro_lock:
            if _pyro_app is None:
                future = asyncio.run_coroutine_threadsafe(_pyro_connect(loop), loop)
                _pyro_app = future.result(timeout=120)
    return _pyro_app


async def _pyro_download(app, peer_id, message_id, dest_path):
    """coroutine يعمل على الـ loop الخلفي — لا يستدعي دوال متزامنة."""
    msg = await app.get_messages(int(peer_id), message_ids=int(message_id))
    if msg is None or not msg.media:
        raise Exception("لم أجد الرسالة/الملف لدى MTProto")
    return await app.download_media(msg, file_name=dest_path)


def download_media_mtproto(peer_id, message_id, dest_path):
    """
    تحميل أي ملف عبر Pyrogram / MTProto دون قيد الـ 20MB الخاص بـ bot.get_file.
    peer_id = معرف المحادثة (رقم المستخدم في المحادثة الخاصة)، message_id = معرف الرسالة.
    يعمل حتى 2GB. آمن للنداء من أي ترايد (يُرسل إلى الـ loop المخصص).
    """
    app = get_pyro_client()
    loop = _ensure_pyro_loop()
    future = asyncio.run_coroutine_threadsafe(
        _pyro_download(app, peer_id, message_id, dest_path), loop
    )
    return future.result(timeout=3600)


def download_file_streaming(bot_token, file_path, dest_path):
    """تحميل الملف مباشرة من خوادم التيليجرام بتدفق — أسرع وأصح للملفات الكبيرة من bot.download_file"""
    url = f"https://api.telegram.org/file/bot{bot_token}/{file_path}"
    with requests.get(url, stream=True, timeout=(30, 3600)) as r:
        r.raise_for_status()
        with open(dest_path, 'wb') as f:
            for chunk in r.iter_content(chunk_size=1024 * 1024):
                if chunk:
                    f.write(chunk)
    return dest_path


def download_any_media(bot_token, file_id, chat_id, message_id, dest_path, is_photo=False):
    """
    يحمّل الملف بأي طريقة تعمل:
    1) get_file (يعمل للملفات حتى 20MB) — تحميل متدفق مباشر.
    2) إذا فشل (ملف أكبر من 20MB) → تحميل عبر MTProto/Pyrogram حتى 2GB.
    يرجع مسار الملف أو يرمي استثناء.
    """
    try:
        file_info = bot.get_file(file_id)
        download_file_streaming(bot_token, file_info.file_path, dest_path)
        return dest_path
    except Exception:
        try:
            res = download_media_mtproto(chat_id, message_id, dest_path)
            if res is None:
                raise Exception("MTProto أعاد مسار فارغ")
            return res
        except telebot.apihelper.ApiTelegramException as tl_err:
            raise tl_err
        except Exception as mte:
            raise Exception(f"فشل التحميل عبر MTProto: {mte}")

def get_youtube_service():
    if not os.path.exists('token.json'):
        return None
    try:
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(None)
            with open('token.json', 'w') as f:
                f.write(creds.to_json())
        return build('youtube', 'v3', credentials=creds)
    except Exception:
        return None

def send_main_menu(chat_id):
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn_subs = types.InlineKeyboardButton("👥 اشتراكات القناة", callback_data="show_subs")
    btn_create = types.InlineKeyboardButton("🎬 رفع فيديو", callback_data="create_video")
    btn_name = types.InlineKeyboardButton("✏️ تغيير اسم القناة", callback_data="change_name")
    btn_avatar = types.InlineKeyboardButton("🖼 صورة القناة", callback_data="change_avatar")
    markup.add(btn_subs, btn_create)
    markup.add(btn_name, btn_avatar)
    bot.send_message(chat_id, "📌 القائمة الرئيسية:\nاختر الإجراء الذي تريده:", reply_markup=markup)

# ================== تسجيل الدخول ==================
@bot.message_handler(commands=['start'])
def start_cmd(message):
    if os.path.exists('token.json'):
        send_main_menu(message.chat.id)
    else:
        markup = types.InlineKeyboardMarkup()
        markup.add(types.InlineKeyboardButton("🔑 تسجيل الدخول بحساب جوجل", callback_data="login"))
        bot.send_message(message.chat.id, "أهلاً بك في بوت إدارة يوتيوب 🎬\n\nيجب عليك تسجيل الدخول أولاً لربط القناة.", reply_markup=markup)

@bot.callback_query_handler(func=lambda call: call.data == "login")
def login_callback(call):
    try:
        bot.answer_callback_query(call.id)
        chat_id = call.message.chat.id
        flow = Flow.from_client_config(CLIENT_CONFIG, scopes=SCOPES, redirect_uri='http://localhost')
        auth_url, _ = flow.authorization_url(access_type='offline', prompt='consent')
        parsed = urlparse(auth_url)
        state = parse_qs(parsed.query)['state'][0]
        oauth_flows[chat_id] = {'flow': flow, 'state': state}

        msg = (
            "🔗 خطوات تسجيل الدخول:\n\n"
            f"1. اضغط هنا لتسجيل الدخول: {auth_url}\n"
            "2. سجل دخول بحساب القناة ووافق على الصلاحيات.\n"
            "3. المتصفح هيحولك لصفحة خطأ (localhost).\n"
            "4. انسخ الرابط من شريط العنوان وأرسله هنا."
        )
        bot.send_message(chat_id, msg, disable_web_page_preview=True)
        bot.register_next_step_handler(call.message, process_auth_url)
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ خطأ: {e}")

def process_auth_url(message):
    link = (message.text or "").strip()
    if "localhost" not in link or "code=" not in link:
        bot.reply_to(message, "❌ أرسل رابط يبدأ بـ localhost ويحتوي على code=...")
        bot.register_next_step_handler(message, process_auth_url)
        return

    try:
        parsed = urlparse(link)
        sent_state = parse_qs(parsed.query).get('state', [None])[0]
        stored = oauth_flows.get(message.chat.id)

        if not stored:
            bot.reply_to(message, "⏳ أعد الضغط على '🔑 تسجيل الدخول' ثم أرسل الرابط الجديد.")
            return

        if sent_state and stored.get('state') and sent_state != stored['state']:
            bot.reply_to(message, "❌ رابط قديم. اضغط '🔑 تسجيل الدخول' مرة أخرى وأرسل الرابط الجديد.")
            return

        flow = stored['flow']
        flow.fetch_token(authorization_response=link)
        creds = flow.credentials

        with open('token.json', 'w') as f:
            f.write(creds.to_json())

        oauth_flows.pop(message.chat.id, None)
        bot.send_message(message.chat.id, "✅ تم تسجيل الدخول وربط القناة بنجاح!")
        send_main_menu(message.chat.id)
    except Exception as e:
        bot.reply_to(message, f"❌ خطأ: {e}\nأرسل /start")

# ================== عرض المشتركين ==================
@bot.callback_query_handler(func=lambda call: call.data == "show_subs")
def show_subscribers(call):
    bot.answer_callback_query(call.id)
    try:
        youtube = get_youtube_service()
        if not youtube:
            bot.send_message(call.message.chat.id, "❌ أنت غير مسجل الدخول. أرسل /start")
            return
        response = youtube.channels().list(mine=True, part='statistics,snippet').execute()
        if 'items' in response:
            ch = response['items'][0]
            name = ch['snippet']['title']
            subs = ch['statistics'].get('subscriberCount', 'غير متاح')
            videos = ch['statistics'].get('videoCount', '0')
            bot.send_message(call.message.chat.id, f"📊 القناة: {name}\n👥 المشتركون: {subs}\n🎬 الفيديوهات: {videos}")
        else:
            bot.send_message(call.message.chat.id, "❌ لم يتم العثور على القناة.")
    except Exception as e:
        bot.send_message(call.message.chat.id, f"❌ خطأ: {e}")

# ================== تغيير اسم القناة ==================
@bot.callback_query_handler(func=lambda call: call.data == "change_name")
def change_name_start(call):
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    user_data[chat_id] = {'action': 'change_name'}
    msg = bot.send_message(chat_id, "✏️ أرسل اسم القناة الجديد:")
    bot.register_next_step_handler(msg, process_new_name)

def process_new_name(message):
    chat_id = message.chat.id
    new_name = (message.text or "").strip()
    if not new_name:
        msg = bot.reply_to(message, "❌ الاسم فارغ. أرسل اسم القناة الجديد:")
        bot.register_next_step_handler(msg, process_new_name)
        return

    status = bot.send_message(chat_id, "⏳ جاري تغيير اسم القناة...")
    try:
        youtube = get_youtube_service()
        if not youtube:
            bot.edit_message_text("❌ أنت غير مسجل الدخول. أرسل /start", chat_id=chat_id, message_id=status.message_id)
            return

        response = youtube.channels().list(mine=True, part='id,snippet').execute()
        channel_id = response['items'][0]['id']

        youtube.channels().update(
            part='snippet',
            body={
                'id': channel_id,
                'snippet': {'title': new_name}
            }
        ).execute()

        bot.edit_message_text(f"✅ تم تغيير اسم القناة إلى: **{new_name}**", chat_id=chat_id, message_id=status.message_id, parse_mode="Markdown")
        send_main_menu(chat_id)
    except Exception as e:
        bot.edit_message_text(f"❌ خطأ أثناء تغيير الاسم: {e}", chat_id=chat_id, message_id=status.message_id)

# ================== تغيير صورة القناة ==================
@bot.callback_query_handler(func=lambda call: call.data == "change_avatar")
def change_avatar_start(call):
    bot.answer_callback_query(call.id)
    chat_id = call.message.chat.id
    user_data[chat_id] = {'action': 'change_avatar'}
    msg = bot.send_message(chat_id, "🖼 أرسل الصورة الجديدة لصورة القناة (كصورة عادية، يفضَّل مقاس 2560x1440):")
    bot.register_next_step_handler(msg, process_new_avatar)

def process_new_avatar(message):
    chat_id = message.chat.id
    if not message.photo:
        msg = bot.reply_to(message, "❌ هذه ليست صورة. أرسل الصورة بشكل طبيعي:")
        bot.register_next_step_handler(msg, process_new_avatar)
        return

    status = bot.send_message(chat_id, "⏳ جاري تحميل الصورة ورفعها...")
    avatar_path = None
    try:
        file_id = message.photo[-1].file_id
        avatar_path = f"avatar_{chat_id}.jpg"
        avatar_path = download_any_media(BOT_TOKEN, file_id, message.chat.id, message.message_id, avatar_path)

        youtube = get_youtube_service()
        if not youtube:
            bot.edit_message_text("❌ أنت غير مسجل الدخول. أرسل /start", chat_id=chat_id, message_id=status.message_id)
            return

        response = youtube.channels().list(mine=True, part='id,brandingSettings').execute()
        channel_id = response['items'][0]['id']

        # رفع الصورة كبانر للقناة ثم ربطها بالإعدادات
        banner_media = MediaFileUpload(avatar_path, mimetype='image/jpeg')
        banner_resp = youtube.channelBanners().insert(media_body=banner_media).execute()
        banner_url = banner_resp.get('url')

        youtube.channels().update(
            part='brandingSettings',
            body={
                'id': channel_id,
                'brandingSettings': {
                    'image': {'bannerExternalUrl': banner_url}
                }
            }
        ).execute()

        bot.edit_message_text(
            "✅ تم تحديث صور banner القناة بنجاح!\n"
            "(لاحظ: صورة البروفايل/الأيقونة الصغيرة يُعدل من حساب جوجل، وهذا البانر هو الظاهر أعلى القناة)",
            chat_id=chat_id, message_id=status.message_id
        )
        send_main_menu(chat_id)
    except Exception as e:
        bot.edit_message_text(f"❌ خطأ: {e}", chat_id=chat_id, message_id=status.message_id)
    finally:
        if avatar_path and os.path.exists(avatar_path):
            os.remove(avatar_path)

# ================== إنشاء ورفع فيديو ==================
@bot.callback_query_handler(func=lambda call: call.data == "create_video")
def start_create_video(call):
    bot.answer_callback_query(call.id)
    user_data[call.message.chat.id] = {}
    msg = bot.send_message(call.message.chat.id, "🎵 الخطوة 1/4: أرسل الملف الصوتي.")
    bot.register_next_step_handler(msg, process_audio)

def process_audio(message):
    if not message.audio and not message.voice:
        msg = bot.reply_to(message, "❌ هذا ليس ملفاً صوتياً. أرسل ملف صوتي.")
        bot.register_next_step_handler(msg, process_audio)
        return

    bot.send_message(message.chat.id, "⏳ جاري تحميل الصوت... (قد يستغرق وقتاً للملفات الكبيرة)")
    file_id = message.audio.file_id if message.audio else message.voice.file_id
    audio_path = f"audio_{message.chat.id}.mp3"
    try:
        audio_path = download_any_media(BOT_TOKEN, file_id, message.chat.id, message.message_id, audio_path)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ فشل تحميل الصوت: {e}")
        return
    user_data[message.chat.id]['audio'] = audio_path

    msg = bot.send_message(message.chat.id, "🖼 الخطوة 2/4: أرسل الصورة (ستُستخدم كخلفية + صورة مصغرة تلقائياً).")
    bot.register_next_step_handler(msg, process_image)

def process_image(message):
    if not message.photo:
        msg = bot.reply_to(message, "❌ هذه ليست صورة. أرسل الصورة بشكل طبيعي.")
        bot.register_next_step_handler(msg, process_image)
        return

    bot.send_message(message.chat.id, "⏳ جاري تحميل الصورة...")
    file_id = message.photo[-1].file_id
    image_path = f"image_{message.chat.id}.jpg"
    try:
        image_path = download_any_media(BOT_TOKEN, file_id, message.chat.id, message.message_id, image_path)
    except Exception as e:
        bot.send_message(message.chat.id, f"❌ فشل تحميل الصورة: {e}")
        return
    user_data[message.chat.id]['image'] = image_path

    msg = bot.send_message(message.chat.id, "📝 الخطوة 3/4: أرسل عنوان الفيديو.")
    bot.register_next_step_handler(msg, process_title)

def process_title(message):
    user_data[message.chat.id]['title'] = message.text
    msg = bot.send_message(message.chat.id, "📋 الخطوة 4/4: أرسل وصف الفيديو.")
    bot.register_next_step_handler(msg, process_description)

def process_description(message):
    chat_id = message.chat.id
    user_data[chat_id]['desc'] = message.text

    status_msg = bot.send_message(chat_id, "⚙️ جاري دمج الصورة والصوت وإنشاء الفيديو...")

    audio_path = user_data[chat_id]['audio']
    image_path = user_data[chat_id]['image']
    video_path = f"video_{chat_id}.mp4"

    try:
        # إنشاء الفيديو
        command = [
            'ffmpeg', '-y', '-loop', '1', '-i', image_path, '-i', audio_path,
            '-c:v', 'libx264', '-tune', 'stillimage', '-c:a', 'copy',
            '-pix_fmt', 'yuv420p', '-shortest', video_path
        ]
        subprocess.run(command, check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        bot.edit_message_text("🚀 جاري الرفع على يوتيوب...", chat_id=chat_id, message_id=status_msg.message_id)

        youtube = get_youtube_service()
        if not youtube:
            bot.edit_message_text("❌ أنت غير مسجل الدخول. أرسل /start", chat_id=chat_id, message_id=status_msg.message_id)
            return

        # رفع الفيديو
        request_body = {
            'snippet': {
                'title': user_data[chat_id]['title'],
                'description': user_data[chat_id]['desc'],
                'categoryId': '22'
            },
            'status': {
                'privacyStatus': 'public',
                'selfDeclaredMadeForKids': False
            }
        }

        media = MediaFileUpload(video_path, chunksize=-1, resumable=True, mimetype='video/mp4')
        request = youtube.videos().insert(part="snippet,status", body=request_body, media_body=media)
        response = request.execute()

        video_id = response.get('id')
        youtube_link = f"https://youtu.be/{video_id}"

        # تحميل الصورة المصغرة تلقائياً
        try:
            thumbnail_media = MediaFileUpload(image_path, mimetype='image/jpeg')
            youtube.thumbnails().set(videoId=video_id, media_body=thumbnail_media).execute()
            thumb_note = "\n🖼 تم تعيين الصورة كصورة مصغرة تلقائياً!"
        except Exception as te:
            thumb_note = f"\n⚠️ تم الرفع لكن فشل تعيين الصورة المصغرة: {te}"

        bot.edit_message_text(
            f"✅ تم الرفع بنجاح!{thumb_note}\n\n🎬 رابط الفيديو:\n{youtube_link}",
            chat_id=chat_id, message_id=status_msg.message_id
        )
        send_main_menu(chat_id)

    except subprocess.CalledProcessError:
        bot.edit_message_text("❌ خطأ أثناء إنشاء الفيديو.", chat_id=chat_id, message_id=status_msg.message_id)
    except Exception as e:
        bot.edit_message_text(f"❌ خطأ أثناء الرفع: {e}", chat_id=chat_id, message_id=status_msg.message_id)
    finally:
        for f_path in [audio_path, image_path, video_path]:
            if os.path.exists(f_path):
                os.remove(f_path)

# ================== تشغيل البوت ==================
if __name__ == "__main__":
    print("البوت يعمل الآن...")
    bot.infinity_polling()
